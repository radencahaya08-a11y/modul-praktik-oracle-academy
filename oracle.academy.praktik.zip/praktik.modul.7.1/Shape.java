
public class Shape {
    private int numSides;
    private boolean regular;

    // Constructor pertama
    public Shape() {
        numSides = 0;
        regular = false;
    }

    // Constructor kedua
    public Shape(int numSides, boolean regular) {
        this.numSides = numSides;
        this.regular = regular;
    }

    // Getter
    public int getNumSides() {
        return numSides;
    }

    public boolean isRegular() {
        return regular;
    }

    // Setter
    public void setNumSides(int numSides) {
        this.numSides = numSides;
    }

    public void setRegular(boolean regular) {
        this.regular = regular;
    }
}
