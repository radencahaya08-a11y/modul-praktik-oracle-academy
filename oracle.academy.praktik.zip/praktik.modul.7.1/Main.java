
public class Main {
    public static void main(String[] args) {
        Student student1 = new Student("Mary Jones");
        student1.addCourse(14, 46);

        Student student2 = new Student("John Stiner");
        student2.addCourse(60, 173);

        Student student3 = new Student("Ari Samala");
        student3.addCourse(31, 69);
        student3.addCourse(13, 52);

        System.out.println("Nama: Mary Jones");
        System.out.println("IP: " + student1.getGPA());

        System.out.println("\nNama: John Stiner");
        System.out.println("IP: " + student2.getGPA());

        System.out.println("\nNama: Ari Samala");
        System.out.println("IP: " + student3.getGPA());
    }
}
