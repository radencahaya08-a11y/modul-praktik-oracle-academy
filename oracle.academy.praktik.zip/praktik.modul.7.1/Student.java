
public class Student {
    private String name;
    private int credit;
    private double gpa;
    private double qualityPoints;

    // Constructor
    public Student(String name) {
        this.name = name;
        credit = 0;
        gpa = 0.0;
        qualityPoints = 0.0;
    }

    // Method a: menghitung IP
    public double getGPA() {
        if (credit == 0) {
            return 0.0;
        }

        gpa = qualityPoints / credit;
        return gpa;
    }

    // Method b: memperbarui kredit dan poin mutu
    public void addCourse(int newCredit, double newPoints) {
        credit += newCredit;
        qualityPoints += newPoints;
        gpa = getGPA();
    }
}
