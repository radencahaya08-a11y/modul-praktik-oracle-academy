
public class Student extends Person {

    private String nim;
    private double gpa;
    private String major;
    private String degree;
    private int expectedYear;

    public Student(String firstName, String middleName,
                   String lastName, java.util.Date dateOfBirth,
                   String nim, String major, String degree,
                   int expectedYear) {

        super(firstName, middleName, lastName, dateOfBirth);

        this.nim = nim;
        this.major = major;
        this.degree = degree;
        this.expectedYear = expectedYear;
        this.gpa = 0.0;
    }

    public String getNim() {
        return nim;
    }

    public double getGpa() {
        return gpa;
    }

    public String getMajor() {
        return major;
    }

    public String getDegree() {
        return degree;
    }

    public int getExpectedYear() {
        return expectedYear;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public void calculateGPA(String[] grades) {

        double total = 0;

        for (int i = 0; i < grades.length; i++) {

            switch (grades[i]) {
                case "A": total += 4.0; break;
                case "A-": total += 3.67; break;
                case "B+": total += 3.33; break;
                case "B": total += 3.0; break;
                case "B-": total += 2.67; break;
                case "C+": total += 2.33; break;
                case "C": total += 2.0; break;
                case "D": total += 1.0; break;
                case "F": total += 0.0; break;
                default:
                    System.out.println("Nilai tidak valid: " + grades[i]);
                    return;
            }
        }

        if (grades.length > 0) {
            gpa = total / grades.length;
        }
    }
}
