
import java.util.Date;

public class Main {

    public static void main(String[] args) {

        Student student1 = new Student(
            "Andi",
            "Putra",
            "Wijaya",
            new Date(2007, 5, 15),
            "12345",
            "Ilmu Komputer",
            "Sarjana",
            2029
        );

        String[] grades = {"A", "B+", "A-", "B"};

        student1.calculateGPA(grades);

        System.out.println("Nama       : " + student1.getName());
        System.out.println("NIM        : " + student1.getNim());
        System.out.println("Jurusan    : " + student1.getMajor());
        System.out.println("Gelar      : " + student1.getDegree());
        System.out.println("Tahun Lulus: " + student1.getExpectedYear());
        System.out.println("GPA        : " + student1.getGpa());

        student1.setMajor("Matematika");

        System.out.println("Jurusan Baru: " + student1.getMajor());
    }
}
