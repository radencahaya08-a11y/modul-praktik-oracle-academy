
public class RumusMatematika {
    public static void main(String[] args) {

        double x = 2;
        double y = 3;

        double a = Math.sqrt(Math.pow(x, 5) - 6) / 4;
        double b = Math.pow(x, y) - Math.pow(6, x);
        double c = 4 * Math.cos(y / 5) - Math.sin(Math.pow(x, 2));
        double d = Math.pow(x, 4) - Math.sqrt(6 * x - Math.pow(y, 3));
        double e = 1 / (y - 1 / (x - 2 * y));
        double f = 7 * Math.cos(Math.sqrt(5 - Math.sqrt(3 * x - 4)));

        System.out.println("a = " + a);
        System.out.println("b = " + b);
        System.out.println("c = " + c);
        System.out.println("d = " + d);
        System.out.println("e = " + e);
        System.out.println("f = " + f);
    }
}