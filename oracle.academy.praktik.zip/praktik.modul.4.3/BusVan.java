import java.util.Scanner;

public class BusVan {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        final int KAPASITAS_BUS = 45;

        System.out.print("Masukkan jumlah penumpang: ");
        int penumpang = input.nextInt();

        int jumlahBus = penumpang / KAPASITAS_BUS;
        int penumpangVan = penumpang % KAPASITAS_BUS;

        System.out.println("Jumlah bus: " + jumlahBus);
        System.out.println("Penumpang naik van: " + penumpangVan);

        input.close();
    }
}