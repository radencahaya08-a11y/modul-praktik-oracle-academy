
import java.util.Scanner;

public class PesanRahasia {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        String pesan = "";
        int angka;
        int jumlah = 0;

        while (jumlah < 10) {
            System.out.print("Masukkan angka ke-" + (jumlah + 1) + ": ");
            angka = input.nextInt();

            if (angka >= 1 && angka <= 7) {
                switch (angka) {
                    case 1:
                        pesan += "D";
                        break;
                    case 2:
                        pesan += "W";
                        break;
                    case 3:
                        pesan += "E";
                        break;
                    case 4:
                        pesan += "L";
                        break;
                    case 5:
                        pesan += "H";
                        break;
                    case 6:
                        pesan += "O";
                        break;
                    case 7:
                        pesan += "R";
                        break;
                }

                jumlah++;
            } else {
                System.out.println("Angka tidak valid! Masukkan angka 1-7.");
            }
        }

        System.out.println("Pesan rahasia: " + pesan);

        input.close();
    }
}
