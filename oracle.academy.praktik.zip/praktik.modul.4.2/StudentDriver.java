
public class StudentDriver {
    public static void main(String[] args) {

        Student student1 = new Student(
            "Raden", "Cahaya", "123456789", "Active"
        );

        student1.displayInfo();
    }
}