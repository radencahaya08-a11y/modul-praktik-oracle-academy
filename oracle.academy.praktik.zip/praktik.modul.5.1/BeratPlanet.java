
import java.util.Scanner;

public class BeratPlanet {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter your weight on Earth (lbs): ");
        double beratBumi = input.nextDouble();

        System.out.println("\nChoose a planet:");
        System.out.println("1. Merkurius");
        System.out.println("2. Venus");
        System.out.println("3. Mars");
        System.out.println("4. Jupiter");
        System.out.println("5. Saturnus");
        System.out.println("6. Uranus");
        System.out.println("7. Neptunus");

        System.out.print("Enter your choice (1-7): ");
        int pilihan = input.nextInt();

        String planet = "";
        double faktor = 0;

        switch (pilihan) {
            case 1:
                planet = "Mercury";
                faktor = 0.38;
                break;
            case 2:
                planet = "Venus";
                faktor = 0.91;
                break;
            case 3:
                planet = "Mars";
                faktor = 0.38;
                break;
            case 4:
                planet = "Jupiter";
                faktor = 2.36;
                break;
            case 5:
                planet = "Saturn";
                faktor = 0.92;
                break;
            case 6:
                planet = "Uranus";
                faktor = 0.89;
                break;
            case 7:
                planet = "Neptune";
                faktor = 1.13;
                break;
            default:
                System.out.println("Invalid choice!");
                input.close();
                return;
        }

        double beratPlanet = beratBumi * faktor;

        System.out.println("Your weight on " + planet + " is "
                + beratPlanet + " lbs.");

        input.close();
    }
}
