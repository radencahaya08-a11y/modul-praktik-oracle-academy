
public class TernaryPractice {
    public static void main(String[] args) {

        int x = 5;

        boolean hasil = (x <= 7) ? true : false;

        System.out.println("Nilai x: " + x);
        System.out.println("Hasil: " + hasil);
    }
}