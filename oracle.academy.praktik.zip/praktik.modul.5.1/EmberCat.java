
import java.util.Scanner;

public class EmberCat {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        double tinggi, panjang, lebar;
        double luasDinding, luasLangit, totalLuas;
        int ember5Liter, ember1Liter;
        double sisaLuas;
        double totalHarga;

        System.out.print("Masukkan tinggi ruangan (kaki): ");
        tinggi = input.nextDouble();

        System.out.print("Masukkan panjang ruangan (kaki): ");
        panjang = input.nextDouble();

        System.out.print("Masukkan lebar ruangan (kaki): ");
        lebar = input.nextDouble();

        luasDinding = 2 * tinggi * panjang
                    + 2 * tinggi * lebar;

        luasLangit = panjang * lebar;
        totalLuas = luasDinding + luasLangit;

        ember5Liter = (int) (totalLuas / 1500);
        sisaLuas = totalLuas - ember5Liter * 1500;

        ember1Liter = (int) Math.ceil(sisaLuas / 300);

        if (ember1Liter >= 5) {
            ember5Liter++;
            ember1Liter = 0;
        }

        totalHarga = ember5Liter * 15 + ember1Liter * 4;

        System.out.println("\n=== HASIL PERHITUNGAN ===");
        System.out.println("Luas dinding: " + luasDinding
                + " kaki persegi");
        System.out.println("Luas langit-langit: " + luasLangit
                + " kaki persegi");
        System.out.println("Total luas yang dicat: " + totalLuas
                + " kaki persegi");
        System.out.println("Ember 5 liter: " + ember5Liter);
        System.out.println("Ember 1 liter: " + ember1Liter);
        System.out.println("Total biaya: $" + totalHarga);

        input.close();
    }
}
