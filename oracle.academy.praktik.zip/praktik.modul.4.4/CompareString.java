
public class CompareString {
    public static void main(String[] args) {
        String teks1 = "abc";
        String teks2 = "abc";
        String teks3 = new String("abc");

        System.out.println(teks1.equals(teks2));
        System.out.println(teks1.equals(teks3));

        System.out.println(teks1 == teks2);
        System.out.println(teks1 == teks3);

        System.out.println(teks1.compareTo("abc"));
        System.out.println(teks1.compareTo("abd"));
    }
}

