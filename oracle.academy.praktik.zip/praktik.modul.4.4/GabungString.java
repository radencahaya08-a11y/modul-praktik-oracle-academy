
public class GabungString {
    public static void main(String[] args) {

        String kata1 = new String("Selamat");
        String kata2 = new String("Belajar");

        String kata3 = kata1 + " " + kata2;

        System.out.println("String pertama: " + kata1);
        System.out.println("String kedua: " + kata2);
        System.out.println("Hasil gabungan: " + kata3);
    }
}