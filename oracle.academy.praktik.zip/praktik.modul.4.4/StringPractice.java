
public class StringPractice {
    public static void main(String[] args) {

        String myString = "abc";

        String myString2 = new String("abc");

        String myString3;
        myString3 = "abc";

        System.out.println(myString);
        System.out.println(myString2);
        System.out.println(myString3);
    }
}
