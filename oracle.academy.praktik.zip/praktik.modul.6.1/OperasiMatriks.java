import java.util.Scanner;

public class OperasiMatriks {

    static Scanner input = new Scanner(System.in);
    static int[][] A = new int[2][2];
    static int[][] B = new int[2][2];
    static boolean matriksAIsi = false;
    static boolean matriksBIsi = false;

    public static void main(String[] args) {
        char pilihan;

        do {
            System.out.println("\n=== MENU OPERASI MATRIKS ===");
            System.out.println("a. Masukkan Matriks A");
            System.out.println("b. Masukkan Matriks B");
            System.out.println("c. Tampilkan A + B");
            System.out.println("d. Tampilkan A - B");
            System.out.println("e. Tampilkan A * B");
            System.out.println("f. Keluar");
            System.out.print("Pilih menu: ");

            pilihan = input.next().toLowerCase().charAt(0);

            switch (pilihan) {
                case 'a':
                    A = masukkanMatriks("A");
                    matriksAIsi = true;
                    break;

                case 'b':
                    B = masukkanMatriks("B");
                    matriksBIsi = true;
                    break;

                case 'c':
                    if (siap()) {
                        tampilkan(operasi("tambah"));
                    }
                    break;

                case 'd':
                    if (siap()) {
                        tampilkan(operasi("kurang"));
                    }
                    break;

                case 'e':
                    if (siap()) {
                        tampilkan(kaliMatriks());
                    }
                    break;

                case 'f':
                    System.out.println("Program selesai.");
                    break;

                default:
                    System.out.println("Pilihan tidak valid!");
            }

        } while (pilihan != 'f');

        input.close();
    }

    static int[][] masukkanMatriks(String nama) {
        int[][] matriks = new int[2][2];

        System.out.println("Masukkan elemen Matriks " + nama + ":");

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print("Baris " + (i + 1)
                        + ", kolom " + (j + 1) + ": ");
                matriks[i][j] = input.nextInt();
            }
        }

        return matriks;
    }

    static boolean siap() {
        if (!matriksAIsi || !matriksBIsi) {
            System.out.println("Masukkan Matriks A dan B terlebih dahulu!");
            return false;
        }
        return true;
    }

    static int[][] operasi(String jenis) {
        int[][] hasil = new int[2][2];

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                if (jenis.equals("tambah")) {
                    hasil[i][j] = A[i][j] + B[i][j];
                } else {
                    hasil[i][j] = A[i][j] - B[i][j];
                }
            }
        }

        return hasil;
    }

    static int[][] kaliMatriks() {
        int[][] hasil = new int[2][2];

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                for (int k = 0; k < 2; k++) {
                    hasil[i][j] += A[i][k] * B[k][j];
                }
            }
        }

        return hasil;
    }

    static void tampilkan(int[][] matriks) {
        System.out.println("Hasil:");

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print(matriks[i][j] + "\t");
            }
            System.out.println();
        }
    }
}

