
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        Card[] hand = new Card[5];
        int jumlahKartu = 0;
        int totalPoin = 0;
        String jawaban;

        // Membuat dua kartu acak pertama
        for (int i = 0; i < 2; i++) {
            int suitNumber = (int)(Math.random() * 4.0 + 1);
            int faceNumber = (int)(Math.random() * 13.0 + 1);

            hand[jumlahKartu] = new Card(suitNumber, faceNumber);
            jumlahKartu++;
        }

        do {
            // Menampilkan semua kartu dan menghitung poin
            totalPoin = 0;

            System.out.println("\nKartu dalam Hand:");

            for (int i = 0; i < jumlahKartu; i++) {
                System.out.println(hand[i]);
                totalPoin += hand[i].getPoints();
            }

            System.out.println("Total poin: " + totalPoin);

            if (totalPoin > 21) {
                System.out.println("Total poin melebihi 21!");
                break;
            }

            if (jumlahKartu == 5) {
                System.out.println("Jumlah kartu sudah mencapai 5.");
                break;
            }

            System.out.print("Mau mengambil kartu lagi? (y/n): ");
            jawaban = input.nextLine();

            if (jawaban.equalsIgnoreCase("y")) {
                int suitNumber = (int)(Math.random() * 4.0 + 1);
                int faceNumber = (int)(Math.random() * 13.0 + 1);

                hand[jumlahKartu] = new Card(suitNumber, faceNumber);
                jumlahKartu++;
            } else {
                break;
            }

        } while (true);

        System.out.println("\nPermainan selesai.");
        input.close();
    }
}
