
public class Hand {
    Card[] cards = new Card[5];
    int cardCount = 0;

    public void addCard(Card card) {
        if (cardCount < 5 && card != null) {
            cards[cardCount] = card;
            cardCount++;
        }
    }

    public int getPoints() {
        int total = 0;
        int aceCount = 0;

        for (int i = 0; i < cardCount; i++) {
            total += cards[i].points;

            if (cards[i].name.equals("Ace")) {
                aceCount++;
            }
        }

        while (total > 21 && aceCount > 0) {
            total -= 10;
            aceCount--;
        }

        return total;
    }

    public void printHand() {
        for (int i = 0; i < cardCount; i++) {
            System.out.println(cards[i]);
        }

        System.out.println("Total poin: " + getPoints());
    }
}
