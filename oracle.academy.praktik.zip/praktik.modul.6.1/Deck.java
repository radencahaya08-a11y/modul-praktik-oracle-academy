
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;

public class Deck {
    Card[] cardArray = new Card[52];

    Deck() {
        int cardCount = 0;

        for (int i = 1; i <= 4; i++) {
            for (int j = 1; j <= 13; j++) {
                cardArray[cardCount] = new Card(i, j);
                cardCount++;
            }
        }
    }

    public void shuffle() {
        List<Card> cards = new ArrayList<>();

        Collections.addAll(cards, cardArray);
        Collections.shuffle(cards);

        cardArray = cards.toArray(new Card[0]);
    }

    public Card drawCard() {
        for (int i = 0; i < cardArray.length; i++) {
            if (cardArray[i] != null) {
                Card drawn = cardArray[i];
                cardArray[i] = null;
                return drawn;
            }
        }

        return null;
    }

    public void print() {
        for (Card card : cardArray) {
            if (card != null) {
                System.out.println(card);
            }
        }
    }
}
