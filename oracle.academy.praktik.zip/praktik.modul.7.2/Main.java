
public class Main {

    public static Fish nicestFish(Fish fish1, Fish fish2) {
        if (fish1.getFriendliness() > fish2.getFriendliness()) {
            return fish1;
        } else {
            return fish2;
        }
    }

    public static void main(String[] args) {

        Fish Amber = new Fish("AngelFish", 5);
        Fish James = new Fish("Guppy", 3);

        System.out.println("Ikan 1: Amber");
        System.out.println("Jenis: " + Amber.typeOfFish);
        System.out.println("Friendliness: " + Amber.getFriendliness());

        System.out.println();

        System.out.println("Ikan 2: James");
        System.out.println("Jenis: " + James.typeOfFish);
        System.out.println("Friendliness: " + James.getFriendliness());

        Fish hasil = nicestFish(Amber, James);

        System.out.println();
        System.out.println("Ikan yang paling ramah:");
        
        if (hasil == Amber) {
            System.out.println("Amber");
        } else {
            System.out.println("James");
        }

        System.out.println("Jenis: " + hasil.typeOfFish);
        System.out.println("Friendliness: " + hasil.getFriendliness());
    }
}
